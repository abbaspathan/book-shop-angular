import { Component } from '@angular/core';

@Component({
    templateUrl:"./welcome.component.html",
    // selector:"app-home"
})
export class WelcomeComponent{

}